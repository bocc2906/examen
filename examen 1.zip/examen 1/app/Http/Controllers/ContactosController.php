<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\contacto;

class ContactosController extends Controller
{
    public function index(){
        $contacto = Contacto::all();
        return view('contactos', compact('contactos'));
    }

    public function create(){
        return view('agregarContacto');
    }

    public function store(Request $request){
        $nvaContacto = new Contacto();
        $nvaContacto->codigoEntrada = $request->input('codigoEntrada');
        $nvaContacto->nombre = $request->input('nombre');
        $nvaContacto->apellido = $request->input('apellido');
        $nvaContacto->correp = $request->input('correo');
        $nvaPelicula->telefono = $request->input('telefono');
        
        
        $nvaContacto->save();
        //return $name2;
    }

    public function edit($id){
        $contacto = Contacto::find($id);
        return view('verContacto', compact('contacto'));
    }

    
    public function delete($id){
        $contacto = Contacto::find($id);
        return view('eliminar', compact('pelicula'));
    }
}
