<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route :: get( '/contactos',[ContactosController::class,'index']);

Route :: get( '/contactos/crear',[ContactosController::class ,'create'])->name('contacto.crear');;

Route :: get( '/contactos/guardar',[ContactosController::class ,'store'])->name('contacto.guardar');;

Route :: get( '/contactos/delete/{id}',[ContactosController::class ,'create','delete'])->name('contacto.delete');;
